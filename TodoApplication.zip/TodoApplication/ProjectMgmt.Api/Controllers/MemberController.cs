using Microsoft.AspNetCore.Mvc;
using ProjectMgmt.Api.Clients;
using ProjectMgmt.Api.Factories;

namespace ProjectMgmt.Api.Controllers;

[ApiController]
[Route("projectmgmt/api/v1/member")] 
public class MemberController : ControllerBase
{
    private readonly ITodoClient _todoClient;
    private readonly MemberTaskResponseFactory _factory;

    public MemberController(ITodoClient todoClient, MemberTaskResponseFactory factory)
    {
        _todoClient = todoClient;
        _factory = factory;
    }

    [HttpGet("list/{memberId}/{taskDetails}")]
    public async Task<IActionResult> GetForMember(string memberId, bool taskDetails)
    {
        var all = await _todoClient.GetAllAsync();
        if (taskDetails)
            return Ok(_factory.CreateDetails(memberId, all));
        return Ok(_factory.CreateSummary(memberId, all));
    }
}

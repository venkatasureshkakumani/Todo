using ProjectMgmt.Api.Models;

namespace ProjectMgmt.Api.Factories;

/// <summary>
/// Demonstrates a Creational Pattern (Factory Method) to build either a summary-only
/// response or a detailed response depending on the caller's need.
/// </summary>
public class MemberTaskResponseFactory
{
    public MemberTaskSummary CreateSummary(string memberId, IEnumerable<TodoItemDto> tasks)
    {
        var list = tasks.Where(t => t.MemberId == memberId).ToList();
        var summary = new MemberTaskSummary(
            MemberId: memberId,
            TotalTasks: list.Count,
            Pending: list.Count(t => t.Status == 0),
            InProgress: list.Count(t => t.Status == 1),
            Completed: list.Count(t => t.Status == 2),
            TotalEffort: list.Sum(t => t.TotalEffort)
        );
        return summary;
    }

    public MemberTaskDetails CreateDetails(string memberId, IEnumerable<TodoItemDto> tasks)
    {
        var summary = CreateSummary(memberId, tasks);
        var detailed = tasks.Where(t => t.MemberId == memberId)
                            .OrderByDescending(t => t.TotalEffort)
                            .ToList();
        return new MemberTaskDetails(summary, detailed);
    }
}

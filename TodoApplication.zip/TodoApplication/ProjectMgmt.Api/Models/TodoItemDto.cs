namespace ProjectMgmt.Api.Models;

public record TodoItemDto(
    Guid Id,
    string TaskName,
    string Description,
    DateTime StartDate,
    DateTime EndDate,
    int Status,
    int TotalEffort,
    string? MemberId
);

public record MemberTaskSummary(
    string MemberId,
    int TotalTasks,
    int Pending,
    int InProgress,
    int Completed,
    int TotalEffort
);

public record MemberTaskDetails(
    MemberTaskSummary Summary,
    IEnumerable<TodoItemDto> Tasks
);

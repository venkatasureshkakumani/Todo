
using ProjectMgmt.Api.Models;
using Refit;

namespace ProjectMgmt.Api.Clients;

public interface ITodoClient
{
    [Get("todolist/api/v1/user/list/all?sort=effort_desc&page=1&pageSize=200")]
    Task<IEnumerable<TodoItemDto>> GetAllAsync();
}

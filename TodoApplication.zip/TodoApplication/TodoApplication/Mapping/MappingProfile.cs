using AutoMapper;
using Todo.Api.DTOs;
using Todo.Api.Models;

namespace Todo.Api.Mapping;

public class MappingProfile : Profile
{
    public MappingProfile()
    {
        CreateMap<CreateTodoRequest, TodoItem>()
       .ForMember(d => d.Status, o => o.MapFrom(s => s.Status));
        CreateMap<TodoItem, TodoResponse>();
    }
}

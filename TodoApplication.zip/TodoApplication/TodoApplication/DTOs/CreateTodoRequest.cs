using Todo.Api.Models;

namespace Todo.Api.DTOs;

public record CreateTodoRequest(
    string TaskName,
    string Description,
    DateTime StartDate,
    DateTime EndDate,
    Models.TaskStatus Status,
    int TotalEffort,
    string? MemberId
);

public record UpdateStatusRequest(
    string TaskName
);

public record TodoResponse(
    Guid Id,
    string TaskName,
    string Description,
    DateTime StartDate,
    DateTime EndDate,
    Models.TaskStatus Status,
    int TotalEffort,
    string? MemberId
);

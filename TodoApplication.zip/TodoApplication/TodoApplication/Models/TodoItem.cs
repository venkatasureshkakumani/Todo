using System.ComponentModel.DataAnnotations;

namespace Todo.Api.Models;

public class TodoItem
{
    public Guid Id { get; set; }

    [Required]
    public string TaskName { get; set; } = string.Empty;

    [Required]
    public string Description { get; set; } = string.Empty;

    [Required]
    public DateTime StartDate { get; set; }

    [Required]
    public DateTime EndDate { get; set; }

    [Required]
    public TaskStatus Status { get; set; }

    // Total effort in hours
    [Range(1, int.MaxValue)]
    public int TotalEffort { get; set; }

    public string? MemberId { get; set; } // owner/assignee for ProjectMgmt use-case
}

namespace Todo.Api.Models;

public enum TaskStatus
{
    Pending = 0,
    InProgress = 1,
    Completed = 2
}

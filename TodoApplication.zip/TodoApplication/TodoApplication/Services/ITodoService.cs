using Todo.Api.DTOs;
using Todo.Api.Models;

namespace Todo.Api.Services;

public interface ITodoService
{
    Task<TodoResponse> CreateAsync(CreateTodoRequest req, CancellationToken ct);
    Task<IReadOnlyList<TodoResponse>> GetAllAsync(string? sort, int page, int pageSize, CancellationToken ct);
    Task<TodoResponse?> GetByTaskNameAsync(string taskName, CancellationToken ct);
    Task<TodoResponse> UpdateStatusAsync(string taskStatus, UpdateStatusRequest req, CancellationToken ct);
}

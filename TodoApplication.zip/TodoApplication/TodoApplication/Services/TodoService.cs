using AutoMapper;
using Todo.Api.DTOs;
using Todo.Api.Models;
using Todo.Api.Repositories;
using TaskStatus = Todo.Api.Models.TaskStatus;

namespace Todo.Api.Services;

public class TodoService : ITodoService
{
    private readonly ITodoRepository _repo;
    private readonly IMapper _mapper;

    public TodoService(ITodoRepository repo, IMapper mapper)
    {
        _repo = repo; _mapper = mapper;
    }

    //public TodoService(ITodoRepository repo, IMapper mapper)
    //{
    //    _repo = repo; _mapper = mapper;
    //}

    public async Task<TodoResponse> CreateAsync(CreateTodoRequest req, CancellationToken ct)
    {
        if (req.TotalEffort <= 0) throw new ArgumentException("Total effort must be > 0");
        if (req.EndDate <= req.StartDate) throw new ArgumentException("EndDate must be greater than StartDate");
        var entity = _mapper.Map<TodoItem>(req);
        var saved = await this._repo.AddAsync(entity, ct).ConfigureAwait(false);
        return _mapper.Map<TodoResponse>(saved);
    }

    public async Task<IReadOnlyList<TodoResponse>> GetAllAsync(string? sort, int page, int pageSize, CancellationToken ct)
    {
        var items = await this._repo.GetAllAsync(sort, page, pageSize, ct).ConfigureAwait(false);
        return items.Select(_mapper.Map<TodoResponse>).ToList();
    }

    public async Task<TodoResponse?> GetByTaskNameAsync(string taskName, CancellationToken ct)
    {
        var item = await _repo.GetByTaskNameAsync(taskName, ct).ConfigureAwait(false);
        return item is null ? null : _mapper.Map<TodoResponse>(item);
    }

    public async Task<TodoResponse> UpdateStatusAsync(string taskStatus, UpdateStatusRequest req, CancellationToken ct)
    {
        var existing = await _repo.GetByTaskNameAsync(req.TaskName, ct).ConfigureAwait(false) ?? throw new KeyNotFoundException("Task not found");
        // Status from route
        var now = DateTime.UtcNow;
        if (existing.EndDate < now) existing.Status = TaskStatus.Pending;
        else existing.Status = TaskStatus.Completed;
        // Override only if a valid route value was sent (Pending|InProgress|Completed)
        if (Enum.TryParse<TaskStatus>(taskStatus, true, out var parsed))
            existing.Status = parsed;
        await _repo.UpdateAsync(existing, ct).ConfigureAwait(false);
        return _mapper.Map<TodoResponse>(existing);
    }
}

﻿using FluentValidation;
using Microsoft.AspNetCore.Mvc;
using Todo.Api.DTOs;
using Todo.Api.Services;

namespace TodoApplication.Controllers
{
    //[Route("api/[controller]")]
    //[ApiController]
    //public class MemberController : ControllerBase
    //{
    //}




    [ApiController]
    [Route("todolist/api/v1/user")]
    public class TodoController : ControllerBase
    {
        private readonly ITodoService _svc;
        private readonly IValidator<CreateTodoRequest> _createValidator;
        private readonly IValidator<UpdateStatusRequest> _updateValidator;

        public TodoController(ITodoService svc,
                              IValidator<CreateTodoRequest> createValidator,
                              IValidator<UpdateStatusRequest> updateValidator)
        {
            _svc = svc; _createValidator = createValidator; _updateValidator = updateValidator;
        }

        /// <summary>
        /// Create a new to-do task.
        /// </summary>
        [HttpPost("add-list")]
        [ProducesResponseType(typeof(TodoResponse), 201)]
        public async Task<IActionResult> Add([FromBody] CreateTodoRequest req, CancellationToken ct)
        {
            var vr = await _createValidator.ValidateAsync(req, ct).ConfigureAwait(false);
            if (!vr.IsValid) return ValidationProblem((ValidationProblemDetails)vr.ToDictionary());
            var created = await _svc.CreateAsync(req, ct).ConfigureAwait(false);
            return CreatedAtAction(nameof(GetByName), new { taskName = created.TaskName }, created);
        }

        /// <summary>
        /// Fetch all tasks with sorting and pagination.
        /// </summary>
        [HttpGet("list/all")]
        [ProducesResponseType(typeof(IEnumerable<TodoResponse>), 200)]
        public async Task<IActionResult> GetAll([FromQuery] string? sort = "effort_desc", [FromQuery] int page = 1, [FromQuery] int pageSize = 50, CancellationToken ct = default)
        {
            var items = await _svc.GetAllAsync(sort, Math.Max(1, page), Math.Clamp(pageSize, 1, 200), ct).ConfigureAwait(false);
            return Ok(items);
        }

        /// <summary>
        /// Get a task by name.
        /// </summary>
        [HttpGet("list/{taskName}")]
        [ProducesResponseType(typeof(TodoResponse), 200)]
        [ProducesResponseType(404)]
        public async Task<IActionResult> GetByName([FromRoute] string taskName, CancellationToken ct)
        {
            var item = await _svc.GetByTaskNameAsync(taskName, ct).ConfigureAwait(false);
            return item is null ? NotFound() : Ok(item);
        }

        /// <summary>
        /// Update the task status.
        /// </summary>
        [HttpPut("update/{taskStatus}")]
        [ProducesResponseType(typeof(TodoResponse), 200)]
        public async Task<IActionResult> Update([FromRoute] string taskStatus, [FromBody] UpdateStatusRequest req, CancellationToken ct)
        {
            var vr = await _updateValidator.ValidateAsync(req, ct).ConfigureAwait(false);
            if (!vr.IsValid) return ValidationProblem((ValidationProblemDetails)vr.ToDictionary());
            var updated = await _svc.UpdateStatusAsync(taskStatus, req, ct).ConfigureAwait(false);
            return Ok(updated);
        }
    }

}

using Microsoft.EntityFrameworkCore;
using Todo.Api.Data;
using Todo.Api.Models;

namespace Todo.Api.Repositories;

public class TodoRepository : ITodoRepository
{
    private readonly TodoDbContext _db;
    public TodoRepository(TodoDbContext db) => _db = db;

    async Task<TodoItem> ITodoRepository.AddAsync(TodoItem item, CancellationToken ct)
    {
        _db.TodoItems.Add(item);
        await _db.SaveChangesAsync(ct).ConfigureAwait(false);
        return item;
    }

    async Task<IReadOnlyList<TodoItem>> ITodoRepository.GetAllAsync(string? sort, int page, int pageSize, CancellationToken ct)
    {
        var query = _db.TodoItems.AsNoTracking();
        if (!string.IsNullOrWhiteSpace(sort) && sort.Equals("effort_desc", StringComparison.OrdinalIgnoreCase))
            query = query.OrderByDescending(t => t.TotalEffort);
        else if (!string.IsNullOrWhiteSpace(sort) && sort.Equals("effort_asc", StringComparison.OrdinalIgnoreCase))
            query = query.OrderBy(t => t.TotalEffort);
        else
            query = query.OrderBy(t => t.TaskName);

        return await query
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .ToListAsync(ct).ConfigureAwait(false);
    }

    Task<TodoItem?> ITodoRepository.GetByTaskNameAsync(string taskName, CancellationToken ct)
        => _db.TodoItems.AsNoTracking().FirstOrDefaultAsync(t => t.TaskName == taskName, ct);

    async Task ITodoRepository.UpdateAsync(TodoItem item, CancellationToken ct)
    {
        _db.TodoItems.Update(item);
        await _db.SaveChangesAsync(ct).ConfigureAwait(false);
    }
}

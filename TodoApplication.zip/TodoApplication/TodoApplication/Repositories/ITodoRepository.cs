using Todo.Api.Models;

namespace Todo.Api.Repositories;

public interface ITodoRepository
{
    Task<TodoItem> AddAsync(TodoItem item, CancellationToken ct);
    Task<TodoItem?> GetByTaskNameAsync(string taskName, CancellationToken ct);
    Task<IReadOnlyList<TodoItem>> GetAllAsync(string? sort, int page, int pageSize, CancellationToken ct);
    Task UpdateAsync(TodoItem item, CancellationToken ct);
}

using AutoMapper;
using FluentAssertions;
using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Todo.Api.DTOs;
using Todo.Api.Mapping;
using Todo.Api.Models;
using Todo.Api.Repositories;
using Todo.Api.Services;
using TaskStatus = Todo.Api.Models.TaskStatus;

namespace Todo.UnitTests;

internal sealed class TodoServiceTests
{
    private TodoService _svc = default!;
    private Mock<ITodoRepository> _repo = default!;

    [SetUp]
    public void Setup()
    {
        _repo = new Mock<ITodoRepository>();
        var mapperCfg = new MapperConfiguration(cfg => cfg.AddProfile(new MappingProfile()));
        var mapper = mapperCfg.CreateMapper();
        _svc = new TodoService(_repo.Object, mapper);
    }

    [Test]
    public async Task Create_Should_Enforce_Constraints()
    {
        var badReq = new CreateTodoRequest("Task1", "desc", DateTime.UtcNow, DateTime.UtcNow.AddHours(-1), TaskStatus.Pending, 1, null);
        await FluentActions.Invoking(() => this._svc.CreateAsync(badReq, default)).Should().ThrowAsync<ArgumentException>().ConfigureAwait(false);
    }

    [Test]
    public async Task GetAll_Should_Map_To_Response()
    {
        _repo.Setup(r => r.GetAllAsync(It.IsAny<string?>(), 1, 50, default)).ReturnsAsync(new List<TodoItem> {
            new TodoItem { Id = Guid.NewGuid(), TaskName = "A", Description = "D", StartDate = DateTime.UtcNow, EndDate = DateTime.UtcNow.AddHours(1), Status = TaskStatus.Pending, TotalEffort = 5 }
        });
        var res = await this._svc.GetAllAsync(null, 1, 50, default).ConfigureAwait(false);
        res.Should().HaveCount(1);
        res[0].TaskName.Should().Be("A");
    }
}

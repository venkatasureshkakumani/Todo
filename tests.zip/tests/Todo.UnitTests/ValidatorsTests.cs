using FluentAssertions;
using NUnit.Framework;
using System;
using Todo.Api.DTOs;
using Todo.Api.Models;
using Todo.Api.Validation;

namespace Todo.UnitTests;

internal static class ValidatorsTestsB
{
    [Test]
    public static void CreateTodoRequestValidatorShouldValidateRules()
    {
        var v = new CreateTodoRequestValidator();
        var result = v.Validate(new CreateTodoRequest("", "", DateTime.UtcNow, DateTime.UtcNow.AddHours(-1), TaskStatus.Pending, 0, null));
        result.IsValid.Should().BeFalse();
    }
}
